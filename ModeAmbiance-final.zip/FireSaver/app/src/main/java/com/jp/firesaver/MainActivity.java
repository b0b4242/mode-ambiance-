package com.jp.firesaver;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/** Mode Ambiance full-screen player. */
public class MainActivity extends Activity {
    private SaverView view;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        view = new SaverView(this);
        setContentView(view);
        hideSystemUi();
    }
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
    @Override protected void onResume() { super.onResume(); hideSystemUi(); view.start(); }
    @Override protected void onPause() { if (view != null) view.stop(); super.onPause(); }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (view != null && view.handleRemoteKey(keyCode)) return true;
        finish();
        return true;
    }
    @Override public boolean onBackPressed() { return super.onBackPressed(); }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) finish();
        return true;
    }
}
